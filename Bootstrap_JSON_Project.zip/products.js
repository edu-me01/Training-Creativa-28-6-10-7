async function loadProducts() {
  const res = await fetch('data.json');
  const data = await res.json();
  const container = document.getElementById('products');

  data.products.forEach(product => {
    container.innerHTML += `
      <div class="col-md-4">
        <div class="card mb-4">
          <img src="${product.image}" class="card-img-top" />
          <div class="card-body">
            <h5 class="card-title">${product.name}</h5>
            <p class="card-text">Price: ${product.price} EGP</p>
            <button class="btn btn-success" onclick="addToCart(${product.id})">Add to Cart</button>
          </div>
        </div>
      </div>
    `;
  });
}

function addToCart(productId) {
  fetch('data.json')
    .then(res => res.json())
    .then(data => {
      const product = data.products.find(p => p.id === productId);
      let cart = JSON.parse(localStorage.getItem("cart")) || [];
      cart.push(product);
      localStorage.setItem("cart", JSON.stringify(cart));
      alert("Product added to cart");
    });
}

loadProducts();